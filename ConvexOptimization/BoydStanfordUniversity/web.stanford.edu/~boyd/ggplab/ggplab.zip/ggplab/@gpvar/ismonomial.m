function r = ismonomial(obj)
% GPVAR/ISMONOMIAL  Returns that the input GP variable is a monomial.
%

r = 1; % single GP variable can always be though of as a monomial
