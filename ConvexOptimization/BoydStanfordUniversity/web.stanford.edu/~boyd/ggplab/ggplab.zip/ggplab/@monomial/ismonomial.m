function r = ismonomial(obj)
% MONOMIAL/ISMONOMIAL  Returns that the input monomial is a monomial.
%

r = 1; % this is always true 
