% Computes a fast MPC simulation run via a cmex function call.
% See fast_mpc/index.html for usage.
% See paper Fast Model Predictive Control via Online Optimization
% for details of algorithm.
