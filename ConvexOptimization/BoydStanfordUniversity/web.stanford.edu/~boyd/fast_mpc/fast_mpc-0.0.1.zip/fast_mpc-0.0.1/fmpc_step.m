% Computes one step of fast MPC via a cmex function call.
% See fast_mpc/index.html for usage.
% See paper Fast Model Predictive Control via Online Optimization
% for details of algorithm.
