% log chebychev approximation
load log_chebychev_data
SDPSOL_FILENAME = 'log_chebychev';
sdpsol