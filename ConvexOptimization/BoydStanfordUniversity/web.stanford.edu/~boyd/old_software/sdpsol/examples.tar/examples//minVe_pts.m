% find the minimum-volume ellipsoid in R^2
% containing given points.
load exp_data
[n,K]=size(X);

% call sdpsol
SDPSOL_FILENAME = 'minVe_pts';
sdpsol

% make the plot
clg
plot(X(1,:),X(2,:),'+')
hold on
plotellip(A'*A,2*A'*b,b'*b-1,':');
tmp=ceil(1.25*max(max(abs(X))));
axis([-tmp tmp -tmp tmp])
axis('square')
axis('off')
hold off
