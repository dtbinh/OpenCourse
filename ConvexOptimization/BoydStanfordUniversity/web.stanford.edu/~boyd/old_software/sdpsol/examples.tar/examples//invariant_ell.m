% find an invariant ellipsoid of a linear system with uncertain,
% time-varying, unity-bounded, diaginal feedback.
A=[-0.3000         0         0         0         0         0         0
         0         0         0         0    1.0000         0         0
         0         0         0         0         0    1.0000         0
         0         0         0         0         0         0    1.0000
    0.5500   -1.4000    0.7000         0   -1.0000    0.5000         0
         0    0.7000   -1.4000    0.7000    0.5000   -1.0000    0.5000
         0         0    0.7000   -0.7000         0    0.5000   -0.5000];
B=[0.30  0     0   
   0     0.30  0
   0     0     0.30
   0     0     0
   0.15  0     0
   0     0.15  0
   0     0     0.15];
C=[0 0 0 .1 0 0 0
   0 0 0 0 .1 0 0
   0 0 0 0 0 .1 0];
SDPSOL_FILENAME = 'invariant_ell';
sdpsol