% find the minimum-volume ellipsoid in R^2
%   { x | x^T*A*x + 2*b^T*x + c < 0 }
% containing given ellipsoids
%   { x | x^T*A_i*x + 2*b_i^T*x + c_i < 0 }, i = 1,...,L
% 
% As = [A1 A2 ... AL]:  L 2-by-2 positive definite matrices
% bs = [b1 b2 ... bL]:  L 2-vectors
% cs = [c1 c2 ... cL]:  L scalars
As=[0.1355  0.1148  0.6064 -0.1022  0.7127 -0.0559  0.2706 -0.1379  0.4008 -0.1112
    0.1148  0.4398 -0.1022  0.7344 -0.0559  0.9253 -0.1379  0.2515 -0.1112  0.2107];
bs=[-0.2042    0.8259   -0.0256    0.1827    0.3823
     0.0264   -2.1188    1.0591   -0.3844   -0.8253];
cs=[ 0.2351    5.8250    0.9968   -0.2981    2.6735];
L = size(bs,2);    % L ellipsoids given

SDPSOL_FILENAME = 'minVe_ell';
sdpsol

% form the ellipsoid
c=-1+b'*inv(A)*b;

% make the plot
clg, hold on
for i=1:L
  plotellip(As(:,2*(i-1)+1:2*(i-1)+2),2*bs(:,i),cs(i));
end
[tmpx,tmpy]=plotellip(A,2*b,c,':');
tmp=ceil(1.25*max(max(abs([tmpx,tmpy]))));
axis('square')
axis('off')
hold off