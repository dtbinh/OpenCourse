% positive definite matrix completion with partially specified inverse

SDPSOL_FILENAME = 'mat_completion';
sdpsol