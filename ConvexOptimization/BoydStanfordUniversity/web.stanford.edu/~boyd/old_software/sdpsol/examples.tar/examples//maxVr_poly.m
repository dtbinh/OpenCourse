% find the maximum volume rectangle in a given polytope
% { x | Ax <= b } in R^2.
px = [0 .5 2 3 1];
py = [0 1 1.5 .5 -.5];

% generate A,b
px=px(:)'; py=py(:)';
n = size(px,2);
pxint = sum(px)/n; pyint = sum(py)/n;
px = [px px(1)];
py = [py py(1)];
A = zeros(n,2); b = zeros(n,1);
for i=1:n
  A(i,:) = null([px(i+1)-px(i) py(i+1)-py(i)])';
  b(i) = A(i,:)*.5*[px(i+1)+px(i); py(i+1)+py(i)];
  if A(i,:)*[pxint; pyint]-b(i)>0
    A(i,:) = -A(i,:);
    b(i) = -b(i);
  end
end

Aplus=max(A,zeros(size(A)));
Aminus=max(-A,zeros(size(A)));

% invoke sdpsol
SDPSOL_FILENAME = 'maxVr_poly';
sdpsol

% make the plot
clg
plot(px,py), hold on
plot([u(1) l(1) l(1) u(1) u(1)],[u(2) u(2) l(2) l(2) u(2)])
axis('off')
hold off
