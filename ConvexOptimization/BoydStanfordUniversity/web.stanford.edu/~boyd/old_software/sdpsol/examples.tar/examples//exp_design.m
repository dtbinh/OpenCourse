% D-optimal experiment design problem with 90-10 constraint
load exp_data
C = floor(.1*size(X,2));

SDPSOL_FILENAME = 'exp_design';
sdpsol
