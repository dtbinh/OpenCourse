path('EXAMPLES',path)
