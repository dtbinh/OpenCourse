% Second-Order Cone Programming.
%
%   socp   - Solve general second-order cone program.
%   socp1  - Analytic solution of SOCP with a single constraint.
%
