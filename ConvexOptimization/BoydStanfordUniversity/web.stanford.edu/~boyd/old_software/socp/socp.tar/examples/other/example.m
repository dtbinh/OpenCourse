% simple example

% x^2+y^2<=1
A1=[1 0; 0 1];	b1=[0; 0];
c1=[0; 0];	d1=1;

% y>=0
c2=[0; 1];	d2=0;

f=[1; 1];
A=[A1];
C=[c1'; c2'];
b=[b1];
d=[d1; d2];
N=[2; 0];

x=[0; 0.5];
z=[1; 0];
w=[2; 1];

Nu=5;
abs_tol=1e-4;
rel_tol=0;
target=0;
max_iter=50;

% using primal and dual initial points
[x1,info1,z1,w1,hist1,time1]= ...
	socp(f,A,b,C,d,N,x,z,w,abs_tol,rel_tol,target,max_iter,Nu);

% using only primal initial point
[x2,info2,z2,w2,hist2,time2]= ...
	socp(f,A,b,C,d,N,x,[],[],abs_tol,rel_tol,target,max_iter,Nu);

% without any initial points
[x3,info3,z3,w3,hist3,time3]= ...
	socp(f,A,b,C,d,N,[],[],[],abs_tol,rel_tol,target,max_iter,Nu);



if 1,	% inspect the output of socp

x1
z1
info1
hist1
time1

x3
z3
info3
hist3
time3

end;
