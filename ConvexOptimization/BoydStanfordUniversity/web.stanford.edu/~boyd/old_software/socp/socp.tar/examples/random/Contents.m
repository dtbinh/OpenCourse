% Solve random SOCPs.
% 
% Files:
% 
%   run_short.m    -- script with calls to range_socp.m
% 
%   run.m          -- script with calls to range_socp.m, up to large problems
% 
%   range_r_s.m    -- repeat random_socp.m for a range of sizes,
%                     plot and save results
% 
%   random_socp.m  -- generate and solve a random SOCP with specified sizes
% 
