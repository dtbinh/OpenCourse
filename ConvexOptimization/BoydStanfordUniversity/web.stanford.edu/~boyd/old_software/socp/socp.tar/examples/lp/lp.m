
% solve random LPs with SOCP

gap_red=1e-4;	% sove until the gap is reduced by 1e-4

Nu=[10 20 100];	% list of parameters to be tested

	% lists to record results
list_n=[];
list_iter=[];
list_std=[];

	% range of problem sizes (n variables, 2*n constraints)
for n=20:20:100,

disp('Problem size: n =');
disp(n);
disp('[Nu iter] =');
l_std=[];
l_iter=[];

	% for each parameter value
for i=1:length(Nu),

iter=[];
for k=1:11,		% 11 repetitions to estimate mean and variance

	% generate random LP
	%	minimize	f'*x
	%	subject to	A*x+b>=0
	m=2*n;
	A=[];
	b=[];
	C=random('norm',0,1,m,n);
	x=random('norm',0,1,n,1);
	d=random('unif',1,2,m,1)-C*x;
	z=[];
	w=random('unif',1,2,m,1);
	f=C'*w;
	N=zeros(m,1);

	gap0=f'*x+d'*w;		% compute initial gap
	abs_tol=gap_red*gap0;
	rel_tol=0;
	target=0;
	max_iter=100;

	% solve
	[xo,info,zo,wo,hist,time]=...
	    socp(f,A,b,C,d,N,x,z,w,abs_tol,rel_tol,target,max_iter,Nu(i),0);

	%% solve w/o initial point
	%% [xo,info,zo,wo,hist,time]=...
	%%     socp(f,A,b,C,d,N,x,z,w,abs_tol,rel_tol,target,max_iter,Nu(i),0);

	iter=[iter time(3)];
	disp([Nu(i) time(3)]);

end;	% of for k
l_iter=[l_iter; mean(iter)];
l_std=[l_std; std(iter)];

end;	% of for i
list_n=[list_n; n];
list_iter=[list_iter; l_iter'];
list_std=[list_std; l_std'];

if length(list_n)>1,
	figure(1);
	errorbar(list_n*ones(1,length(Nu)),...
		list_iter, list_std, list_std, '-');
	axis([0 max(list_n) 0 max(max(list_iter))+2]);
	xlabel('n');
	ylabel('i');
	grid on;
end;

%% save lp.mat Nu list_n list_iter list_std

end;	% of for n
