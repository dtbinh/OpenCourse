% function [list_iter,list_time,list_n,list_m]=...
%	range_r_s(Nu, n_min,n_step,n_max, m_min,m_step,m_max, fig, file, new)
%
% Solve random socp problems over a range of n and m,
% where n is the total dimension of the constraints
% and m is the number of problem variables.
%
% If required, plots results and/or saves to file.
%
% PARAMETERS
% Nu:	parameter for socp
% n_min,n_step,n_max:	range of n
% 	(range of n is truncated to ensure that n>=m in all cases)
% m_min,m_step,m_max:	range of m
% fig:	1: plot results; 0: no plots
% file:	name of mat file used to store results
% new:	1: starts a new plot (also if file==[])
%	0: loads previous results from file and appends
%

function [list_iter,list_time,list_n,list_m]=...
	range_r_s(Nu, n_min,n_step,n_max, m_min,m_step,m_max, fig, file, new)

if new | (file==[]),
	list_iter=[];
	list_time=[];
	list_n=[];
	list_m=[];
else
	eval(['load ',file]);
end;

for n= max(n_min, m_max) : n_step : max(n_max, m_max),
for m= m_min : m_step : m_max,
		% solve a random problem
	[iter,time,N]=random_socp(n,m,Nu);
		% record results
	list_iter=[list_iter; iter];
	list_time=[list_time; time];
	list_n=[list_n; n];
	list_m=[list_m; m];
	if fig,
		figure(fig);
		if n_min==n_max,
			x=list_m;
		else
			x=list_n;
		end;
		plot(x, list_iter, 'o');
		axis([0 max(x) 0 ceil(1.2*max(list_iter))]);
		xlabel('n');
		ylabel('i');
	end;
	if ~(file==[]),
		eval(['print /home/mlobo/socp/figures/',file]);
		eval(['save ',file,' list_iter list_time list_n list_m']);
	end;
end;
end;
