% function [iter,time,N]=random_socp(n,m,Nu)
%
% generate and solve random socp with m variables
% and total constraint dimensionality n
%
% each constraint has random dimension, with uniform dist. in [1,m]
%

function [iter,time,N]=random_socp(n,m,Nu)

L=0;
N=[];
nsum=0;
while nsum<n,
	L=L+1;
	N=[N; random('unid',m,1,1)];
	nsum=nsum+N(L);
end;
N(L)=N(L)-(nsum-n);	% the last one will not have unif. distribution...
N=N-1;

A=random('norm',0,1,n-L,m);
b=zeros(n-L,1);
C=random('norm',0,1,L,m);
d=zeros(L,1);

x=random('norm',0,1,m,1);
z=zeros(n-L,1);
w=zeros(L,1);

k=1;
for i=1:L,
	if N(i)>0,
		bi= random('norm',0,1,N(i),1);
		d(i)= 1.1*norm(A(k:k+N(i)-1,:)*x+bi) - C(i,:)*x;
		b(k:k+N(i)-1)= bi;
		zi= random('norm',0,1,N(i),1);
		w(i)= 1.1*norm(zi);
		z(k:k+N(i)-1)= zi;
	else
		d(i)= abs(random('norm',0,1,1,1)) - C(i,:)*x;
		w(i)= abs(random('norm',0,1,1,1));
	end;
	k=k+N(i);
end;
f=A'*z+C'*w;

abs_tol=1e-4*(z'*(A*x+b)+w'*(C*x+d));
rel_tol=0;
max_iter=100;

%keyboard;

[x,info,z,w,hist,time1]=...
	socp(f,A,b,C,d,N,[],[],[],abs_tol,rel_tol,0,max_iter,Nu);
time=time1(1);
iter=time1(3);
