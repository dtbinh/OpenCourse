Nu=10;

range_r_s(Nu, 10,10,200,	10,1,10,	1, ['temp_',int2str(Nu)], 1);
