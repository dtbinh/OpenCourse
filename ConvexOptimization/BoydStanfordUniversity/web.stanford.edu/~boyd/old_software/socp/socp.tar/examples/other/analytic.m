
% SCRIPT: generate and solve socp w/ single constraint.
%  Compare numerical and analytic solutions.
%  Uses pre-defined variable:  new
%   new=1  generate new random problem (should be used on first call)
%   new=0  repeat last problem (i.e. prob. currently in workspace)

if ~exist('new'), new=1; end;

%%% generate problem
if new,		% random problem with real values
	m=100;
	n=10;
	N=[m-1];
	A=random('norm',0,1,m-1,n);
	b=random('norm',0,1,m-1,1);
	c=random('norm',0,1,n,1);
	x=random('norm',0,1,n,1);
	d=1.1*norm(A*x+b)-c'*x;
	z=random('norm',0,1,m-1,1);
	w=1.1*norm(z);
	f=A'*z+c*w;
elseif 0,	% random problem, with integer values (where appropriate)
		% this will generate "degenerate" cases
		% including probs. that are not strictly feas. (if K=0)
	K=0;
	f=[0;0];
	while f==0,
		m=3;
		n=2;
		N=[m-1];
		M=1;	% integer values range from -M to M
		A=random('unid',2*M+1,m-1,n)-M-1;
		b=random('unid',2*M+1,m-1,1)-M-1;
		c=random('unid',2*M+1,n,1)-M-1;
		x=random('unid',2*M+1,n,1)-M-1;
		d=norm(A*x+b)-c'*x+max(0,random('norm',0,1,1,1))+K;
		z=random('unid',2*M+1,m-1,1)-M-1;
		w=norm(z)+K;
		f=A'*z+c*w;
	end
elseif 0,	% "hand-made" problem
	m=3;
	n=2;
	N=[m-1];
	A=[1 0;0 1];
	b=[0;1];
	c=[1; 0];
	d=2;
	x=[0;0];
	z=[0;0];
	w=1;
	f=[-1;0];
end


%%% numerical solution
if 1,
 disp('--- NUMERIC ---');
 tn=cputime;
 [xn,info,zn,wn,hist,time]=socp(f,A,b,c',d,N,x,z,w);
 tn=cputime-tn;
 disp('info =');
 disp(info);
end


%%% analytic solution
disp('--- ANALYTIC ---');
ta=cputime;
[xa,info,za,wa,fsbl,bndd]=socp1(f,A,b,c',d);
ta=cputime-ta;
disp('info =');
disp(info);


%%% results, diagnostics, etc

if 1,
 rel_error=norm(xn-xa)/norm(xa);
 disp(' ');
 disp('[xn, xa] =');
 disp([xn,xa]);
 disp('relative error =');
 disp(rel_error);
 disp('times =');
 disp([tn,ta]);
end;

disp('[fsbl, bndd] =');
disp([fsbl, bndd]);

% disp([norm(A*xa+b), c'*xa+d]);
