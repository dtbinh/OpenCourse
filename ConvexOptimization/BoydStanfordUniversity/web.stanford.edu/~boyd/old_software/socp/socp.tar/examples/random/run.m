Nu=10;

range_r_s(Nu, 10,10,200,	10,1,10,	1, ['t1a_',int2str(Nu)], 1);
range_r_s(Nu, 10,10,200,	50,1,50,	2, ['t2a_',int2str(Nu)], 1);
range_r_s(Nu, 1000,1,1000,	50,10,500,	3, ['t3c_',int2str(Nu)], 1);
range_r_s(Nu, 5000,1,5000,	50,10,500,	4, ['t4c_',int2str(Nu)], 1);
