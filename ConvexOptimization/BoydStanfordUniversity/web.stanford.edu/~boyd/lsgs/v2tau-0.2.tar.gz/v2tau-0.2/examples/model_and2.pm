our %gates =
  (
    inv => {
      inputs => {
        in => 1.0
        },
      internal => 1.0,
      area => 3.0,
      sizes => [1, 2, 4, 8]
    },

    nand => {
      inputs => {
        in0 => 1.33,
        in1 => 1.33
        },
      internal => 2.0,
      area => 6.0,
      sizes => [1, 2, 4, 8]
    }

  );
