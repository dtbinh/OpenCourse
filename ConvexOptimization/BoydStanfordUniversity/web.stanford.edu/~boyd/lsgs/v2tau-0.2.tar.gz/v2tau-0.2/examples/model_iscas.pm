our %gates = 
    (

     and2 => {
	 inputs => {
	     in0 => 1.33, 
	     in1 => 1.33
	     },
	 internal => 4.0, 
	 area => 6, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     and3 => {
	 inputs => {
	     in0 => 1.67, 
	     in1 => 1.67, 
	     in2 => 1.67
	     },
	 internal => 5.0, 
	 area => 6, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     and4 => {
	 inputs => {
	     in0 => 2.00, 
	     in1 => 2.00, 
	     in2 => 2.00, 
	     in3 => 2.00
	     },
	 internal => 10, 
	 area => 5, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     and5 => {
	 inputs => {
	     in0 => 2.33, 
	     in1 => 2.33, 
	     in2 => 2.33, 
	     in3 => 2.33,
	     in4 => 2.33
	     },
	 internal => 10, 
	 area => 6, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     and8 => {
	 inputs => {
	     in0 => 3.33,
	     in1 => 3.33, 
	     in2 => 3.33, 
	     in3 => 3.33,
	     in4 => 3.33, 
	     in5 => 3.33, 
	     in6 => 3.33, 
	     in7 => 3.33
	     },
	 internal => 15, 
	 area => 10, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     and9 => {
	 inputs => {
	     in0 => 4, 
	     in1 => 4, 
	     in2 => 4, 
	     in3 => 4,
	     in4 => 4, 
	     in5 => 4, 
	     in6 => 4, 
	     in7 => 4,
	     in8 => 4
	     },
	 internal => 15, 
	 area => 10, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     aoi12 => {
	 inputs => {
	     in00 => 2.0, 
	     in01 => 2.1, 
	     in10 => 1.6
	     },
	 internal => 4.0, 
	 area => 4.2, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     aoi21 => {
	 inputs => {
	     in00 => 1.67, 
	     in10 => 2, 
	     in11 => 2.1
	     },
	 internal => 4.0,
	 area => 4.2, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     buf => {
	 inputs => {
	     in => 0.4
	     },
	 internal => 6.0, 
	 area => 4.0, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     inv => {
	 inputs => {
	     in => 1.0
	     },
	 internal => 1.0, 
	 area => 3.0, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     nand2 => {
	 inputs => {
	     in0 => 1.33, 
	     in1 => 1.33
	     },
	 internal => 2.0,
	 area => 5.0, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     nand3 => {
	 inputs => {
	     in0 => 1.67, 
	     in1 => 1.67, 
	     in2 => 1.67
	     },
	 internal => 2.0,
	 area => 5.0, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     nand4 => {
	 inputs => {
	     in0 => 2.00, 
	     in1 => 2.00, 
	     in2 => 2.00, 
	     in3 => 2.00
	     },
	 internal => 2.00, 
	 area => 5.0, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     nor2 => {
	 inputs => {
	     in0 => 1.66,
	     in1 => 1.66
	     },
	 internal => 2.0,
	 area => 5.5,
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     nor3 => {
	 inputs => {
	     in0 => 2.33,
	     in1 => 2.33,
	     in2 => 2.33
	     },
	 internal => 2.0,
	 area => 5.5,
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     nor4 => {
	 inputs => {
	     in0 => 3.00,
	     in1 => 3.00,
	     in2 => 3.00,
	     in3 => 3.00
	     },
	 internal => 2.0,
	 area => 5.5,
	 sizes => [1, 2, 4, 8, 16, 64]
	 },
     
     oai12 => {
	 inputs => {
	     in00 => 2, 
	     in01 => 2, 
	     in10 => 1.4
	     },
	 internal => 4.2,
	 area => 7.0, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     or2 => {
	 inputs => {
	     in0 => 1.66, 
	     in1 => 1.66
	     },
	 internal => 5, 
	 area => 6.0, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },


     or3 => {
	 inputs => {
	     in0 => 2, 
	     in1 => 2,
	     in2 => 2
	     }, 
	 internal => 5, 
	 area => 5.5, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },


     or4 => {
	 inputs => {
	     in0 => 3.0, 
	     in1 => 3.0, 
	     in2 => 3.0, 
	     in3 => 3.0
	     },
	 internal => 5, 
	 area => 5.5, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     or5 => {
	 inputs => {
	     in0 => 3.0, 
	     in1 => 3.0, 
	     in2 => 3.0, 
	     in3 => 3.0,
	     in4 => 3.0
	     },
	 internal => 5, 
	 area => 5.5, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },


     xor2 => {
	 inputs => {
	     in0 => 0.8,
	     in1 => 1.1
	     },
	 internal => 6.0,
	 area => 9.5, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 },

     xorb2 => {
	 inputs => {
	     in0 => 2.6, 
	     in1 => 1.7
	     },
	 internal => 6.0,
	 area => 10.5, 
	 sizes => [1, 2, 4, 8, 16, 64]
	 }
     );
