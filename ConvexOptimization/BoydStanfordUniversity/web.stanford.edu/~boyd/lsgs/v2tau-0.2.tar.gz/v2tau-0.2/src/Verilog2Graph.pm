package Verilog2Graph;

use strict;
use warnings;
use Verilog::Netlist;
use Graph;

#custom packages
use VerilogGraphMisc;
use v2tauMisc;
use GateLib;

#Constructor
sub new {
    
    my $class = shift(@_);
    my $nl = shift(@_);
    my $gates = shift(@_);
    my $wl = shift(@_);

    #Create Graph and Initialize
    my $graph = Graph->new;
    $graph->directed(1);
    $graph->undirected(0);

    my $inputs = "inputs";
    my $outputs = "outputs";
    $graph->add_vertex($inputs);
    $graph->add_vertex($outputs);

    #A flat netlist will only have one top module
    my @top_modules = $nl->top_modules_sorted;
    my $mod = $top_modules[0];
   
    my @cells = $mod->cells;
    my @ports = $mod->ports;

    my %nets_in = ();
    my %nets_out = ();

    my %nets = (in  => \%nets_in,
		out => \%nets_out);

    #Iterate over all cells in the netlist and set up hash structures
    foreach my $cell (@cells) {
	my @pins = $cell->pins;

	(my $gate_name, my $gate_size, my $dummy) = 
	    VerilogGraphMisc::vertex_split($cell->submodname);

	#Look through all pins of the current cell
	foreach my $pin (@pins) {
	    my $pin_name = $pin->name;
	    my $net_name = $pin->netname;
	    
	    # Look for output pins
	    if ($gates->is_output($gate_name, $pin_name) == 1 ) {
		v2tauMisc::add_net(\%nets_out, $net_name, $pin);
	    }

	    # pin is an input pin
	    else {
		v2tauMisc::add_net(\%nets_in, $net_name, $pin);
	    }

	}
    }

    #Iterate over all cells in the netlist and set up graph
    foreach my $cell (@cells) {
	my $inst_name1 = $cell->name;
        my $mod_name1 = $cell->submodname;
	my $vertex1 = VerilogGraphMisc::mod2vertex($mod_name1,$inst_name1);
	(my $gate_name, my $gate_size, my $dummy) =
	    VerilogGraphMisc::vertex_split($vertex1);

	my @pins = $cell->pins;

	foreach my $pin (@pins) {
	    my $pin_name = $pin->name;
	    my $net_name = $pin->netname;

	    # Look for output pins
	    if ($gates->is_output($gate_name, $pin_name) == 1 ) {
		my $input_pin_ref = $nets_in{$net_name};
		if (defined $input_pin_ref) {
		    foreach my $input_pin (@{$input_pin_ref}) {
			my $cell2 = $input_pin->cell;
			my $inst_name2 = $cell2->name;
			my $mod_name2 = $cell2->submodname;
			my $pin_name2 = $input_pin->name;
			my $vertex2 = 
			    VerilogGraphMisc::mod2vertex($mod_name2,
							 $inst_name2);
			
			add_graph_edge($graph,
				       $vertex1,
				       $vertex2,
				       $pin_name2,
				       $pin_name,
				       $net_name,
				       $wl);

		    }

		}
		# this implies a primary output
		else {

		    add_graph_edge($graph,
                                   $vertex1,
                                   $outputs,
                                   "in",
                                   $pin_name,
				   $net_name,
				   $wl);

		}
	    }

	    # pin is an input pin
	    else {
		my $output_pin_ref = $nets_out{$net_name};

		# this implies primary input
		if (not defined $output_pin_ref) {
		    add_graph_edge($graph,
				   $inputs,
				   $vertex1,
				   $pin_name,
				   "input",
				   $net_name,
				   $wl);
		}

	    }  

	}
	


    }

    return ($graph, \%nets);
}


# Create an edge, while adding the proper attributes
# (for better generality maybe the attributes should be arrays 
#  instead of scalars?)
sub add_graph_edge {

    my $graph = shift(@_);
    my $node1 = shift(@_);
    my $node2 = shift(@_);
    my $in_pin = shift(@_);
    my $out_pin = shift(@_);
    my $net_name = shift(@_);
    my $wl = shift(@_);

#    print "adding edge between $node1 and $node2\n";
    $graph->set_edge_attribute( $node1,
				$node2,
				"in_pin",
				$in_pin);

    $graph->set_edge_attribute( $node1,
				$node2,
				"out_pin",
				$out_pin);

    $graph->set_edge_attribute( $node1,
				$node2,
				"net_name",
				$net_name);

    my $wireload = $graph->get_vertex_attribute($node1, "wireload");
    my $numpred = $graph->get_vertex_attribute($node2, "numpred");

    if ($node1 ne "inputs") {

	#lookup the wireload associated with this net
	if (defined $wl) {
	    my $wl_net = $wl->{$net_name};
	    if (defined $wl_net) {
		if (not defined $wireload) {
		    $graph->set_vertex_attribute($node1, "wireload", $wl_net);
		}
		elsif ($wireload != $wl_net) {
		    print "Warning: Inconsistency in wireloads found.\n";
		    print "Net $net_name from $node1 has existing wireload=$wireload\n";
		    print "new wireload=$wl_net\n";
		}		
	    }
	    else {
		if (not defined $graph->get_vertex_attribute($node1, 
							     "wireload")) {
		    $graph->set_vertex_attribute($node1, "wireload", 0);
		}
	    }
	}
	else {
	    $graph->set_vertex_attribute($node1, "wireload", 0);
	}

	if (not defined $numpred) {
	    $graph->set_vertex_attribute($node2, "numpred",1);
	}
	else {
	    $graph->set_vertex_attribute($node2, "numpred",$numpred+1);
	}
    }


}



1;
