# This package accepts a Wireload file and produces a Perl hash that maps 
# net names to wireloads
package WireModel;

use strict;
use warnings;

use Verilog::Netlist;

#Constructor
sub new {
    
    my $class = shift(@_);
    my $wl_file = shift(@_);
    my $nl = shift(@_);
    
    open WL, "< $wl_file" or die "Can't open $wl_file";
    my @wl_lines = <WL>;
    close WL;

    #A flat netlist will only have one top module
    my @top_modules = $nl->top_modules_sorted;
    my $mod = $top_modules[0];
    
    my %wl = ();
    my $lineno = 1;
    foreach my $line (@wl_lines) {
	# ignore both /* */ and // style comments
	if ($line =~ m/^\/\*.*\*\/\s+$/) {}
	elsif ($line =~ m/^\/\/.*$/) {}
	elsif ($line =~ m/(\S+)\s+([\d\.]+).*/) {
	    my $wl_net = $1;
	    my $wl_cap = $2;

	    #ensure the specified net actually exists in the design
	    my $v_net = $mod->find_net($wl_net);

	    if (not defined $v_net) {
		print "** Error while parsing wireload file:$wl_file\n";
		print "** Line $lineno: Net $wl_net doesn't exist in the Verilog\n";
		exit(6);
	    }
	    
	    $wl{$wl_net} = $wl_cap;
	}
	elsif ($line =~ m/(.*\S+.*)$/) {
	    print "** Error while parsing wireload file:$wl_file\n";
	    print "** Line $lineno: $1\n";
	    exit(2);
	}
	$lineno = $lineno + 1;
    }
   
    return \%wl;
}


1;
