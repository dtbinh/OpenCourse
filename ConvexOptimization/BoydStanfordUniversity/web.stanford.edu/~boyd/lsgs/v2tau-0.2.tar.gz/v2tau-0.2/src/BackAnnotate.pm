package BackAnnotate;

use strict;
use warnings;

use Verilog::Netlist;

#custom packages
use VerilogGraphMisc;
use v2tauMisc;

#Constructor
sub new {

    my $class = shift(@_);
    my $src = shift(@_);
    my $gatelistfile = shift(@_);
    my $sizefile = shift(@_);
    my $src_sized = shift(@_);
    my $model_file = shift(@_);

    open ORIG, "< $src" or die "Can't open $src";
    my @verilog_orig = <ORIG>;
    close(ORIG);

    open GATES, "< $gatelistfile" or die "Can't open $gatelistfile";
    my @gates = <GATES>;
    close(GATES);

    open SIZES, "< $sizefile" or die "Can't open $sizefile";
    my @sizes = <SIZES>;
    close(SIZES);

    open SIZED, "> $src_sized" or die "Can't open $src_sized";
    
    my $gates = "";

    if (defined $model_file) {
	$gates = new GateLib($model_file);
    }

    #create the index mapping
    my %indices = ();
    my $i = 0;
    foreach my $instname (@gates) {
	#remove any newlines
	$instname =~ s/\n//;
	$indices{$instname} = $i;
	$i = $i + 1;
    }


    foreach my $line (@verilog_orig) {
	if ($line =~ m/(\S+)_[\d\.]+x\s+(\S+)\s+.*/) {
	    
	    my $i = 0;
	    my $gate = $1;
	    my $inst = $2;

	    my $index = $indices{$inst};

	    if (defined $index) {
		my $size = 1;
		if ($sizes[$index] =~ m/(\S+)/) {
		    $size = $1;
		}

		#do snapping
		if (defined $model_file) {
		    my @allowed_sizes = sort {$a <=> $b} 
		    @{$gates->find_sizes($gate)};
			#print "sizes = @allowed_sizes\n";
		    $size = snapsize(\@allowed_sizes, $size);
		}
		else {
		    $size = sprintf("%.2f", $size);
		}

		my $newgate = VerilogGraphMisc::set_gate_size($gate, $size);
		$line =~ s/\S+_\d+x/$newgate/;
		print SIZED "$line";

	    }
	    else {
		die "Error.  Instance $inst not in $gatelistfile";
	    }
	}

	else {
	    print SIZED "$line";
	}

    }

}

#assume array is sorted increasing
sub snapsize {
    my @allowed_sizes = @{shift(@_)};
    my $size = shift(@_);

    my $i = 0;
    my $upper_ind = -1;
    my $final_ind = 0;
    my $allowed_prev = -100000000;

    foreach my $allowed (@allowed_sizes) {
	if (($size < $allowed) && ($size >= $allowed_prev)) {
	    $upper_ind = $i;
	    last;
	}
	$i = $i + 1;
	$allowed_prev = $allowed;
    }

    #this means the size was too large
    if ($upper_ind < 0) {
	$final_ind = scalar(@allowed_sizes) - 1;
    }
    #this means the size was too small
    elsif ($upper_ind == 0) {
	$final_ind = 0;
    }
    #take the geometric mean, then round
    else {

	my $mean_geo = sqrt($allowed_sizes[$upper_ind-1]*
			    $allowed_sizes[$upper_ind]);
	if ($size <= $mean_geo) {
	    $final_ind = $upper_ind - 1;
	}
	else {
	    $final_ind = $upper_ind ;
	}
    }

    return $allowed_sizes[$final_ind];
}

1;
