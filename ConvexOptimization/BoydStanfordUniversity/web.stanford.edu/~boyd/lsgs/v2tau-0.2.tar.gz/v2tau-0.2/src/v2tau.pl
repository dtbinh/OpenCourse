#!/usr/bin/perl

use strict;
use warnings;

#packages from CPAN#
use Verilog::Netlist;
use Graph;

#custom packages
use Verilog2Graph;
use Graph2lsgs;
use v2tauMisc;
use GateLib;
use WireModel;

if (scalar(@ARGV) != 3)
{
  print "** Error. Incorrect Arguments.\n";
  print_usage();
  exit(1);
}

my $verilog_file = $ARGV[0];
my $wireload_file = $ARGV[1];
my $model_file = $ARGV[2];
my ($name_root, $name_ext) = v2tauMisc::extract_filename($verilog_file);

my $gates = new GateLib($model_file);

# Prepare netlist
print "Reading Verilog Netlist\n";
my $nl = new Verilog::Netlist;
$nl->read_file (filename=>$verilog_file);
print "Reading Verilog Netlist Completed\n";

print "Reading Wireload File\n";
my $wl = WireModel->new($wireload_file, $nl);
print "Reading Wireload File Completed\n";

# Form Directed Acyclic Graph
print "Forming DAG\n";
(my $graph, my $nets) = Verilog2Graph->new($nl, $gates, $wl);
print "Forming DAG Completed\n";

# Create Matlab m-file
print "Creating m-file\n";
my $blah = Graph2lsgs->new($graph, $nets, $model_file, $name_root);
print "Creating m-file Completed\n";

sub print_usage {
print <<EOX;
Usage: v2tau.pl <verilog_file> <wireload> <model> 
       verilog_file: Flat Verilog netlist
       wireload: Describes the wireload on various nets in the design
       model: Defines attributes for each gate used in verilog_file
EOX
}
