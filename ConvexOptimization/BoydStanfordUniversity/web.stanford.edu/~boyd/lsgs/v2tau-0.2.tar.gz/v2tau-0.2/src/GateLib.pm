package GateLib;

use strict;
use warnings;


#Constructor
sub new {
    my $self = shift(@_);
    my $model_file = shift(@_); 

    # declare the %gates hash as global in order to easily 
    # receive it from the model file
    our %gates;

    # use the user-provided model file to form the gate library
    require $model_file;
    $gates{__model_file__} = $model_file;
    bless(\%gates);
    return \%gates;
}

sub lookup_gate_info {
    my $self = shift(@_);
    my $gate = shift(@_);
    my $attr = shift(@_);
   
    my $gate_ref = $self->{$gate};
    if (not defined $gate_ref) {
	my $file = $self->{__model_file__};
	print "** Error in user-provided gate library: $file\n";
	print "** $gate is not a defined gate\n";
	exit(4);
    }

    my $info = $gate_ref->{$attr};
    if (not defined $info) {
	my $file = $self->{__model_file__};
	print "** Error in user-provided gate library: $file\n";
	print "** $attr is not a defined attribute of $gate\n";
	exit(5);
    }

    return $info;
}


sub find_parasitic {
    my $self = shift(@_);
    my $gate = shift(@_);
    return lookup_gate_info($self, $gate, "internal");
}

sub find_le {
    my $self = shift(@_);
    my $gate = shift(@_);
    my $port = shift(@_);
    my $inputs = lookup_gate_info($self, $gate, "inputs");
    my $le = $inputs->{$port};
    if (not defined $le) {
	my $file = $self->{__model_file__};
	print "** Error in user-provided gate library: $file\n";
	print "** $port is not defined as an input port for $gate\n";
	exit(6);
    }
    return $le;
}

sub find_area_slope {
    my $self = shift(@_);
    my $gate = shift(@_);
    return lookup_gate_info($self, $gate, "area");
}

sub find_sizes {
    my $self = shift(@_);
    my $gate = shift(@_);
    return lookup_gate_info($self, $gate, "sizes");
}

sub is_output {
    my $self = shift(@_);
    my $gate = shift(@_);
    my $output = shift(@_);
    my $inputs = lookup_gate_info($self, $gate, "inputs");
    my $is_output = 0;

    if (not defined $inputs->{$output}) {
	$is_output = 1;
    }

    return $is_output;
}

1;
