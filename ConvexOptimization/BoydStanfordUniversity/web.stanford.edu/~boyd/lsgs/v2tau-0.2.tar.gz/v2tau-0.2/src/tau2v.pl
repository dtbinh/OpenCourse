#!/usr/bin/perl

use strict;
use warnings;

#packages from CPAN#
use Verilog::Netlist;
use Graph;
use Getopt::Long;

#custom packages
use Verilog2Graph;
use Graph2lsgs;
use BackAnnotate;
use v2tauMisc;

Getopt::Long::Configure("pass_through");

my %opts = ();
GetOptions("snap=s"=> \$opts{model_file});

if (scalar(@ARGV) != 2)
{
  print "Error! Incorrect Arguments!\n";
  print_usage();
  exit(1);
}

my $verilog_file = $ARGV[0];
my $sizes_file = $ARGV[1];
my ($name_root, $name_ext) = v2tauMisc::extract_filename($verilog_file);
my $gates_file = $name_root."_gates";
my $verilog_sized = $name_root."_sized.".$name_ext;

#check if gates file exists
if (-e $gates_file) {
#    print "Existing file $gates_file found, will be used...\n";
}
else {
    print "File $gates_file not found, creating...\n";
    my $nl = new Verilog::Netlist;
    $nl->read_file (filename=>$verilog_file);
    (my $graph, my $nets) = Verilog2Graph->new($nl);
    my $blah = Graph2lsgs->new($graph, $nets, "no_model", $name_root, 1);
}

my $blah2 = BackAnnotate -> new($verilog_file, 
			       $gates_file, 
			       $sizes_file, 
			       $verilog_sized,
			       $opts{model_file});

print "Back annotation complete.  File $verilog_sized successfully created.\n";

sub print_usage {
print <<EOX;
Usage: tau2v.pl <verilog_file> <sizes> [-snap <model>]
       verilog_file: Flat Verilog netlist
       sizes: ASCII file with vector of gate sizes
       model: Defines attributes for each gate used in verilog_file
EOX
}
