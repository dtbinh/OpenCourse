package VerilogGraphMisc;

use strict;
use warnings;

sub mod2vertex {
    my $mod = shift(@_);
    my $inst = shift(@_);
    $mod =~ s/\s+//;
    $inst =~ s/\s+//;
    my $vertex = $mod."%".$inst;
    return $vertex;
}


sub vertex_split {
    my $vertex = shift(@_);
    my $mod = $vertex;
    my $inst = "inst";

    if ($vertex =~ m/(\S+)%(\S+)$/) {
	$mod = $1;
	$inst = $2;
    }

    my $gate = "gate";
    my $size = 0;
    if ($mod =~ m/(\S+)_([\d\.]+)x$/) {
	$gate = $1;
	$size = $2;
    }

    return ($gate, $size, $inst);
}


sub vertex2gate {
    my $vertex = shift(@_);
    (my $gate, my $size, my $inst) = vertex_split($vertex);
    return $gate;
}

sub vertex2inst {
    my $vertex = shift(@_);
    (my $gate, my $size, my $inst) = vertex_split($vertex);
    return $inst;
}

sub vertex2size {
    my $vertex = shift(@_);
    (my $gate, my $size, my $inst) = vertex_split($vertex);
    return $size;
}

sub set_gate_size {
    my $gate = shift(@_);
    my $size = shift(@_);
    my $mod = $gate."_${size}x";
    return $mod;
}

1;
