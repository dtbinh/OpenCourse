package v2tauMisc;

use strict;
use warnings;

#this adds a cell to a hash keyed by a net name 
#an array of cells is used to handle collisions
sub add_net {
    my $hash_ref = shift(@_);
    my $net_name = shift(@_);
    my $cell_name = shift(@_);

    my $arr_ref = $hash_ref->{$net_name};

    if (defined $arr_ref) {
        push(@{$arr_ref}, $cell_name);
    }
    else {
        my @arr = ();
        push (@arr, $cell_name);
        $hash_ref->{$net_name} = \@arr;
    }
}



sub extract_filename {

    my $filename = shift(@_);

    my $root = "";
    my $ext = "";

    my @arr = split(/\./, $filename);
    my $length = scalar(@arr);

    if ($length > 1) {
	$ext = pop(@arr);
	$root = join(".",@arr);
    }
    else {
	$root = $arr[0];
    }

    return ($root, $ext);
}

1;
