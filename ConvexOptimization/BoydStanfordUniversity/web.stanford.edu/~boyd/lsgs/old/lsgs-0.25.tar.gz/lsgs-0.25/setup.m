function setup()
%setup: sets up the lsgs toolbox 
%   - compiles C file in ./src/mex and puts the MEX files ./lib
%   - adds $PWD/src, $PWD/lib to MATLAB path.

% LSGS Large-scale Gate Sizing MATLAB Toolbox.
% Copyright 2007 Siddharth Joshi and Stephen Boyd.
% See the file `copyright' (included in the distribution) 
% for full copyright information.

fprintf('\nSetup...\n');

fprintf('Compiling C files in ./src/mex ...\n');
mex ./src/mex/cslackandlpath.c -outdir ./lib;
mex ./src/mex/dttldtodt.c -outdir ./lib;
mex ./src/mex/gatedelays.c -outdir ./lib;
mex ./src/mex/gatedelays_softmin.c -outdir ./lib;
mex ./src/mex/jacobianut.c -outdir ./lib;
mex ./src/mex/jacobianux.c -outdir ./lib;
mex ./src/mex/nlbs.c -outdir ./lib;
mex ./src/mex/nlbs_softmax.c -outdir ./lib;
mex ./src/mex/timingasg.c -outdir ./lib;
fprintf('C files compiled. MEX file located in ./lib.\n');

DD=pwd;
addpath([DD '/lib']);
addpath([DD '/src']);
fprintf('Added $PWD/src and $PWD/lib to path.\n');
fprintf('Setup completed.\n');

fprintf('\nTo test lsgs run the scripts in ./examples directory.\n');
fprintf('If a script fails (because of a MEX file related error) see the users'' guide.\n');



    
    
